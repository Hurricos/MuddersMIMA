//Copyright 2022-2023(c) John Sullivan


#ifndef modes_h
	#define modes_h

	void operatingModes_handler(void);

#endif