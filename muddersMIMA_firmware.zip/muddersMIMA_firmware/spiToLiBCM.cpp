//Copyright 2022-2023(c) John Sullivan

#include "muddersMIMA.h"

//JTS2doLater: use whichever SPI slave mode starts with clock high when CS pulls down

////////////////////////////////////////////////////////////////////////////////////